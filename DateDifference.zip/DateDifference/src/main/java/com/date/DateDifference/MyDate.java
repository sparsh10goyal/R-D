package com.date.DateDifference;

public class MyDate {
	
	private int dd,mm,yyyy;
	
	public MyDate(int dd, int mm, int yyyy) {
		super();
		this.dd = dd;
		this.mm = mm;
		this.yyyy = yyyy;
	}

	public int getDd() {
		return dd;
	}

	

	public int getMm() {
		return mm;
	}

	
	public int getYyyy() {
		return yyyy;
	}



	

	
}
