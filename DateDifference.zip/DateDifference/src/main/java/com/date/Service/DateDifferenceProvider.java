package com.date.Service;

import com.date.DateDifference.MyDate;

public class DateDifferenceProvider {
	private static int DAYS_LEAP_YEAR=366;
	private static int DAYS_NON_LEAP_YEAR=365;
	private static int JAN_DAYS=31;
	private static int FEB_DAYS=28;
	private static int MAR_DAYS=31;
	private static int APRIL_DAYS=30;
	private static int MAY_DAYS=31;
	private static int JUNE_DAYS=30;
	private static int JULY_DAYS=31;
	private static int AUG_DAYS=31;
	private static int SEPT_DAYS=30;
	private static int OCT_DAYS=31;
	private static int NOV_DAYS=30;
	private static int DEC_DAYS=31;
	
	private static int DAYS_MONTHS_ARRAY[]= {JAN_DAYS, FEB_DAYS, MAR_DAYS, APRIL_DAYS, MAY_DAYS,
			JUNE_DAYS, JULY_DAYS, AUG_DAYS, SEPT_DAYS, OCT_DAYS, NOV_DAYS, DEC_DAYS};
	
	public static int getDateDifference(MyDate startDate,MyDate endDate) {

		if(sameDate(startDate,endDate) && sameMonth(startDate,endDate) && sameYear(startDate,endDate)) {
			return 0;
		}
		
		else if(sameMonth(startDate,endDate) && sameYear(startDate,endDate)) {
			return endDate.getDd()-startDate.getDd();
		}
		
		else if(sameYear(startDate, endDate))
		{
			return (remainingDaysInMonth(startDate)+daysInInterviningMonth(startDate, endDate)+leadingDays(endDate));
		}
		
		else {
			return (remainingMonths(startDate)+interviningYear(startDate, endDate)+leadingMonths(endDate));
		}

	}



	private static boolean sameDate(MyDate startDate, MyDate endDate) {
		if(startDate.getDd()==endDate.getDd())
		   return true;
		return false;
	}
	
	private static boolean sameMonth(MyDate startDate, MyDate endDate) {
		if(startDate.getMm()==endDate.getMm())
			return true;
		return false;
	}
	
	private static boolean sameYear(MyDate startDate, MyDate endDate) {
		if(startDate.getYyyy()==endDate.getYyyy())
			return true;
		return false;
	}
	
	private static int remainingDaysInMonth(MyDate startDate) {
		int remainingDaysInMonth=0;
		if(isLeapYear(startDate) && startDate.getMm()==2)
			remainingDaysInMonth=1;
		remainingDaysInMonth+=DAYS_MONTHS_ARRAY[startDate.getMm()-1]-startDate.getDd();
		return remainingDaysInMonth;
	}
	
	private static int leadingDays(MyDate endDate) {
		return endDate.getDd();
	}
	
	private static int daysInInterviningMonth(MyDate startDate, MyDate endDate) {
		int daysInInterviningMonthDays=0;
		if(isLeapYear(startDate) && startDate.getMm()<2 && endDate.getMm()>2)
			daysInInterviningMonthDays=1;
		for(int i=startDate.getMm();i<endDate.getMm()-1;i++)
		{   
			daysInInterviningMonthDays+=DAYS_MONTHS_ARRAY[i];
		}
		return daysInInterviningMonthDays;
	}
	
	private static boolean isLeapYear(MyDate startDate) {
		if((startDate.getYyyy()%4==0 && startDate.getYyyy()%100!=0)|| startDate.getYyyy()%400==0) 
			return true;
		return false;
	}


	private static int remainingMonths(MyDate startDate) {
		 int remainingYearDays=0;
		 int remainDaysInMonth=remainingDaysInMonth(startDate);
		 int daysInInterviningMonthDays=daysInInterviningMonth(startDate, new MyDate(0, 13, startDate.getYyyy()));
		 remainingYearDays=remainDaysInMonth+daysInInterviningMonthDays;
		 return remainingYearDays;
	}
	
	private static int interviningYear(MyDate startDate, MyDate endDate) {
		int interviningYearDays=0;
		for(int j=startDate.getYyyy()+1;j<endDate.getYyyy();j++)
		{
			if((j%4==0 && j%100!=0) || j%400==0)
				interviningYearDays+=366;
			else
				interviningYearDays+=365;
		}
		return interviningYearDays;
	}
	
	private static int leadingMonths(MyDate endDate) {
		int leadingYearDays=0;
		int daysInInterviningMonthDays=daysInInterviningMonth(new MyDate(0, 0, endDate.getYyyy()), endDate);
		int leadingDaysInMonth=endDate.getDd();
		leadingYearDays=leadingDaysInMonth+daysInInterviningMonthDays;
		return leadingYearDays;
	}
	public static void main(String[] args) {
		System.out.println(leadingMonths(new MyDate(18, 12, 2012)));
	}
}
