package com.date.Test;

import java.util.ArrayList;

import com.date.DateDifference.MyDate;
import com.date.Service.DateDifferenceProvider;

public class DateDifferenceTest {

	
	public static void main(String[] args) {
		
		ArrayList<MyDateTestRecords> testData = new ArrayList<MyDateTestRecords>();
		testData.add(new MyDateTestRecords(new MyDate(06, 04, 2011),new MyDate(06,04,2011), 0));
		testData.add(new MyDateTestRecords(new MyDate(06, 04, 2011),new MyDate(18,04,2011), 12));
		testData.add(new MyDateTestRecords(new MyDate(06, 04, 2011),new MyDate(18,05,2011), 42));
		testData.add(new MyDateTestRecords(new MyDate(06, 04, 2011),new MyDate(18,06,2011), 73));
		testData.add(new MyDateTestRecords(new MyDate(06, 04, 2011),new MyDate(18,12,2011), 256));
		testData.add(new MyDateTestRecords(new MyDate(06, 04, 2011),new MyDate(18,12,2012), 622));
		testData.add(new MyDateTestRecords(new MyDate(06, 04, 2011),new MyDate(18,12,2013), 987));
		testData.add(new MyDateTestRecords(new MyDate(06, 04, 2011),new MyDate(18,12,2113), 37511));
		testData.add(new MyDateTestRecords(new MyDate(06, 04, 2011),new MyDate(18,12,2413), 147084));
		testData.add(new MyDateTestRecords(new MyDate(06, 04, 2011),new MyDate(18,12,2813), 293181));
		testData.add(new MyDateTestRecords(new MyDate(06, 01, 2011),new MyDate(06,03,2011), 59));
		testData.add(new MyDateTestRecords(new MyDate(06, 01, 2012),new MyDate(06,03,2012), 60));
		testData.add(new MyDateTestRecords(new MyDate(06, 02, 2012),new MyDate(06,03,2012), 29));
		testData.add(new MyDateTestRecords(new MyDate(22, 01, 2012),new MyDate(15,11,2012), 298));
		testData.add(new MyDateTestRecords(new MyDate(06, 02, 2012),new MyDate(06,12,2012), 304 ));
		
		for(MyDateTestRecords testCase: testData) {
			MyDate startDate= testCase.startDate;
			MyDate endDate= testCase.endDate;
			long expectedResults=testCase.expectedResult;
			long ObtainedResults=DateDifferenceProvider.getDateDifference(startDate, endDate);
			if(expectedResults==ObtainedResults)
				System.out.println("Test "+(1 + testData.lastIndexOf(testCase)) + " Passed "
			+ ObtainedResults +"= obtainedResult " + expectedResults +"= expectedResult");
			else
				System.err.println("Test "+(1 + testData.lastIndexOf(testCase)) + " Failed "
						+ ObtainedResults +"= obtainedResult " + expectedResults +"= expectedResult");
			
		}
	
}
}





/*int	result = 0;
int std=startDate.getDd();
int etd=endDate.getDd();
int stm=startDate.getMm();
int etm=endDate.getMm();
int sty=startDate.getYyyy();
int ety=endDate.getYyyy();
if((stm==etm)&&(sty==ety) ) {
	
	result=etd-std;
	
}

else if(sty==ety) {
	if(etm == 01 || etm == 03 || etm == 05|| etm == 07 || etm == 8 || etm == 10 || etm == 12 ) {
		result=etd-std +30;
	}
}
else if()

return result;		

*/






