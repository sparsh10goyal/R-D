package com.lambda.practice;

public interface MyInterface1 {
	
	public abstract void method1();
}
