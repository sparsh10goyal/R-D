package com.lambda.practice;

public class TestClass {
	public static void main(String[] args) {
		
	MyInterface1 myInterface1 = () -> System.out.println("Lambda Expression 1") , myInterface2 = () -> System.out.println("Lambda Expression 2");
	myInterface1.method1();
	
	myInterface2.method1();
	System.out.println("------------");
	MyInterface2 myInterface3=(n1,n2) -> n1>n2;
	boolean value=myInterface3. method2(6,5);
	System.out.println("Largest of two numbers  "+value);
	System.out.println("------------");
	}
}
