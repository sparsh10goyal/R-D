package com.mmt.MakeMyTrip;

public class FlightDetails {
	int flightno;
	String arrivaltime,departuretime,traveltime;
	String flightname,origin,destination;
	int cost;
	static int flightnoAutoGen;
	{
		flightno=++flightnoAutoGen;
		
	}
	
	
	

	public FlightDetails(String flightname, String origin, String destination, String departuretime, String arrivaltime, String traveltime, int cost) {
		super();
		
		this.arrivaltime = arrivaltime;
		this.departuretime = departuretime;
		this.traveltime = traveltime;
		this.flightname = flightname;
		this.origin = origin;
		this.destination = destination;
		this.cost = cost;
	}



	@Override
	public String toString() {
		return "FlightDetails [flightno=" + flightno + ", arrivaltime=" + arrivaltime + ", departuretime="
				+ departuretime + ", traveltime=" + traveltime + ", flightname=" + flightname + ", origin=" + origin
				+ ", destination=" + destination + ", cost=" + cost + "]";
	}



	public int getFlightno() {
		return flightno;
	}



	public void setFlightno(int flightno) {
		this.flightno = flightno;
	}



	public String getArrivaltime() {
		return arrivaltime;
	}



	public void setArrivaltime(String arrivaltime) {
		this.arrivaltime = arrivaltime;
	}



	public String getDeparturetime() {
		return departuretime;
	}



	public void setDeparturetime(String departuretime) {
		this.departuretime = departuretime;
	}



	public String getTraveltime() {
		return traveltime;
	}



	public void setTraveltime(String traveltime) {
		this.traveltime = traveltime;
	}



	public String getFlightname() {
		return flightname;
	}



	public void setFlightname(String flightname) {
		this.flightname = flightname;
	}



	public String getOrigin() {
		return origin;
	}



	public void setOrigin(String origin) {
		this.origin = origin;
	}



	public String getDestination() {
		return destination;
	}



	public void setDestination(String destination) {
		this.destination = destination;
	}



	public int getCost() {
		return cost;
	}



	public void setCost(int cost) {
		this.cost = cost;
	}
	
	
	
	
	
}

	
	