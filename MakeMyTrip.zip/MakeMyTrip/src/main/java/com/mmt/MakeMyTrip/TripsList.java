package com.mmt.MakeMyTrip;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
 
 
 
 
 
public class TripsList {
ArrayList<FlightDetails> acc1 = new ArrayList();
      
      
       public ArrayList<FlightDetails> getAllFlightList() {
              return acc1;
      
       }
      
      
       public void add(FlightDetails f) {
              acc1.add(f);
       }
      
      
       public ArrayList<FlightDetails> deleteFlightByNo(int flightNo) {
                for(FlightDetails acc:acc1) {
                     if(acc.getFlightno()==flightNo) {
                             acc1.remove(flightNo);
                            return acc1;
                    
               }
                }
               throw new RuntimeException("flight details not found");
               }    
      
      
 
 
    public ArrayList<FlightDetails> updateFlight(int flightNo, String flightname) {
        for(FlightDetails acc:acc1) {
               if(acc.getFlightno()==flightNo) {
              acc.setFlightname(flightname);
              return acc1;
        }
}
 
        throw new RuntimeException("Flight does not exist");
}
 
 
 
 
public ArrayList<FlightDetails> getAllflightdetails() {
        return acc1;
       
 }
 
public FlightDetails getflightByNo(int flightNo) {
        for(FlightDetails acc:acc1) {
              if(acc.getFlightno()==flightNo)
                     return acc;
             
        }
        throw new RuntimeException("flight details not found");
        }
     
 public ArrayList<FlightDetails> sortFlightByName()
{
       Collections.sort(acc1,new Comparator<FlightDetails>() {
             
               
               public int compare(FlightDetails acc1,FlightDetails acc2)
              {
                     return acc1.getFlightname().compareTo(acc2.getFlightname());
                    
      
               }
       });
      
               return acc1;
             
        
        
 }
  
 
 
      
}
 