package com.mmt.MakeMyTrip;

public class User {
    public static void main(String[] args)
    {
          
          
TripsList aa=new TripsList();
   
    aa.add(new FlightDetails("Jet Airways","Bangalore","Hyderabad","7:00","9:00","2:00",2000));
   
    aa.add(new FlightDetails("Spice Jet","Mumbai","Delhi","12:00","4:00","4:00",5000));
    aa.add(new FlightDetails("Air India","Bangalore","New Delhi","9:00","12:00","3:00",4000));
    aa.add(new FlightDetails("Go Air","Chandigarh","New Delhi","15:00","18:00","3:00",3500));
   
   
   
    for(FlightDetails acc:aa.getAllflightdetails()) {
    System.out.println(acc);
    }
    System.out.println("--------------------------");
    System.out.println("--------------------------");
    
    System.out.println(aa.getflightByNo(1));
    System.out.println("--------------------------");
    for(FlightDetails acc:aa.updateFlight(2,"Go Indigo")) {
           System.out.println(acc);

           }
    System.out.println("--------------------------");

   
    for(FlightDetails acc:aa.deleteFlightByNo(3)) {
           System.out.println(acc);

           }
    /*System.out.println("--------------------------");
    for(BankAccount acc:a.sortAccountByName()) {
           System.out.println(acc);
           }
           */
    }


}
