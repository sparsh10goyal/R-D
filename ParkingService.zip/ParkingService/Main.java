package com.Parking.ParkingService;

import java.util.Map;

public class Main {
	public static void main(String[] args) {
		Park park=new Park();
		OwnerDetails owner=new OwnerDetails("Sparsh1322", "1564361", "11:11");
		park.addCar(new OwnerDetails("Sparsh","8288811768", "11:00"));
		park.addCar(new OwnerDetails("Spash","8288811768", "11:00"));
		park.addCar(new OwnerDetails("Sprsh","8288811768", "11:00"));
	park.addCar(new OwnerDetails("parsh","8288811768", "11:00"));
	park.addCar(new OwnerDetails("Sparsh1","8288811768", "11:00"));
		park.addCar(new OwnerDetails("Sparsh2","8288811768", "11:00"));
		park.addCar(new OwnerDetails("Sparsh3","8288811768", "11:00"));
		park.addCar(new OwnerDetails("Sparsh4","8288811768", "11:00"));
		park.addCar(new OwnerDetails("Sparsh5","8288811768", "11:00"));
		park.addCar(new OwnerDetails("Sparsh6","8288811768", "11:00"));
		

		park.addCar(new OwnerDetails("Sparsh7","8288811768", "11:00"));
	//	park.removeCar(new OwnerDetails("Sparsh7","8288811768", "11:00"));
	//	park.removeCar(new OwnerDetails("Sparsh7","8288811768", "11:00"));
	//	park.removeCar(new OwnerDetails("Sparsh7","8288811768", "11:00"));
		//park.removeCar(new OwnerDetails("Sparsh7","8288811768", "11:00"));
			
		park.addCar(owner);
		park.getAllCars();
	for(Map.Entry e	: park.getAllCars() ) {
		System.out.println(e.getKey()+" " + e.getValue());
	}
	System.out.println(park.getCarById(owner.getId()));
	
	}

}
