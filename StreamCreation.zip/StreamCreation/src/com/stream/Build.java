package com.stream;

import java.util.function.Supplier;
import java.util.stream.Stream;

public class Build {
	public static void main(String[] args) {

		Stream <String>build = Stream.<String>builder().add("sp").add("ar").add("sh").build();
		build.forEach(System.out::println);
		System.out.println("-----------");
		
		 Stream<String> supplies = Stream.generate(() ->"sparsh").limit(11);
		supplies.forEach(System.out::println);
}
}