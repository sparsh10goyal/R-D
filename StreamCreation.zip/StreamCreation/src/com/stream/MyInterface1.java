package com.stream;

public interface MyInterface1 {
	
	public abstract void method1();
}
