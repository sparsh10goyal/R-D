package com.stream;

import java.util.List;
import java.util.stream.Stream;
import java.util.ArrayList;

public class ParallelStreamClient {
	public static void main(String[] args) {
		List<Student> list=new ArrayList<>();
		list.add(new Student("ab", 10));
		list.add(new Student("abc", 101));
		list.add(new Student("abcd", 120));
		list.add(new Student("bbcde", 140));
		list.add(new Student("abcdef", 105));
		list.add(new Student("abghikk", 140));
		list.add(new Student("dbhhds", 120));
		Stream<Student> parallelStream= list.parallelStream();
		parallelStream.forEach(s->doProcess(s));
	}

	private static void doProcess(Student s) {
		// TODO Auto-generated method stu
		System.out.println(s);
	}

}
