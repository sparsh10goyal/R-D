package com.logging;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Service {
	private final Logger log = LoggerFactory.getLogger(Service.class);
	
	public void process(String car) {
		log.debug("Processing: {}",car);
	}
	
}
