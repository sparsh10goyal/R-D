package com.logging;

public class ServiceRunner {
	public static void main(String[]args) {
		
		Service car =  new Service();
		car.process("Maruti");
	}
}
