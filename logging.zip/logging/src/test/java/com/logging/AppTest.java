package com.logging;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class AppTest 
{
    @Test
    public void AnswerTrue()
    {
        assertTrue( true );
    }
}
